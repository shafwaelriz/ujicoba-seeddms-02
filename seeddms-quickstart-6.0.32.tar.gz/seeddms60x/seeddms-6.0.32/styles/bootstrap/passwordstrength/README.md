check strength of password
